<?php
/** YOUR LICENSE TEXT HERE **/
$mod_strings = Array (
'CustomerPortal' => 'CustomerPortal',
'LBL_BASIC_SETTINGS'=>'Basic Settings',
'LBL_ADVANCED_SETTINGS'=>'Advanced Settings',
'LBL_MODULE'=>'Module',
'LBL_VIEW_ALL_RECORD'=>'View All Related Records ?',
'YES'=>'Yes',
'NO'=>'No',
'LBL_USER_DESCRIPTION'=>'The selected User\'s profile (above) will be used to control the fields that appear in the Customer Portal.<br />You can enable/disable the fields that are shown in the Customer Portal.',
'SELECT_USERS'=>'Select Users',				
'LBL_DISABLE'=>'Disable',
'LBL_ENABLE' =>'Enable',
'Module' => 'Module',
'Sequence' =>'Sequence',
'Visible'=>'Visible'

);

?>
