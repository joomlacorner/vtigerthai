<?php
/*+*******************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 ******************************************************************************/
$mod_strings = Array (
'FieldFormulas' => 'ฟิลด์ ฟอร์มูล่า',
'LBL_FIELDFORMULAS' => 'ฟิลด์ ฟอร์มูล่า',
'LBL_FIELDFORMULAS_DESCRIPTION' => 'Add custom equations to custom fields',
'LBL_FIELDS' => 'ฟิลด์',
'LBL_FUNCTIONS' => 'ฟังก์ชั่น',
'LBL_FIELD' => 'ฟิลด์',
'LBL_EXPRESSION' => 'สูตรคำนวน',
'LBL_SETTINGS' => 'ตั้งค่า',
'LBL_NEW_FIELD_EXPRESSION_BUTTON' => 'เพิ่ม ฟิลด์สูตรคำนวน',
'LBL_EDIT_EXPRESSION' => 'แก้ไข สูตรคำนวน',
'LBL_MODULE_INFO' => 'สร้างสูตร สำหรับ ',
'NEED_TO_ADD_A' =>'คุณต้องระบุ ประเภทเป็นข้อความหรือตัวเลข ',
'LBL_CUSTOM_FIELD' =>'Custom field',
'LBL_CHECKING'=>'กำลังตรวจสอบ...',
'LBL_SELECT_ONE_DOTDOTDOT'=>'Select one...',
'LBL_TARGET_FIELD'=>'Target field',
'LBL_DELETE_EXPRESSION_CONFIRM'=>'คุณแน่ใจที่จะลบสูตรนี้?',
'LBL_EXAMPLES'=>'ตัวอย่าง',
'LBL_USE_FIELD_VALUE_DASHDASH'=>'-- Use Field Value --',
'LBL_USE_FUNCTION_DASHDASH'=>'-- Use Function --',
);

?>