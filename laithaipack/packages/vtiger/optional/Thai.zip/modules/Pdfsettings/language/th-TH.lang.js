	var pdfconfig_arr = {
				ITEM_INDIVIDUAL_REQUIRED_QUOTES:'For the individual tax mode at quotes you need to select at least one column content for the display of items.',
				ITEM_GROUP_REQUIRED_QUOTES:'For the group tax mode at quotes you need to select at least one column content for the display of items.',
				ITEM_INDIVIDUAL_REQUIRED_PO:'For the individual tax mode at purchase orders you need to select at least one column content for the display of items.',
				ITEM_GROUP_REQUIRED_PO:'For the group tax mode at purchase orders you need to select at least one column content for the display of items.',
				ITEM_INDIVIDUAL_REQUIRED_SO:'For the individual tax mode at sales orders you need to select at least one column content for the display of items.',
				ITEM_GROUP_REQUIRED_SO:'For the group tax mode at sales orders you need to select at least one column content for the display of items.',
				ITEM_INDIVIDUAL_REQUIRED_INV:'For the individual tax mode at invoices you need to select at least one column content for the display of items.',
				ITEM_GROUP_REQUIRED_INV:'For the group tax mode at invoices you need to select at least one column content for the display of items.',
				TAB_GENERAL:'General',
				TAB_GROUP:'group Tax',
				TAB_INDIVIDUAL:'individual Tax'
			};
