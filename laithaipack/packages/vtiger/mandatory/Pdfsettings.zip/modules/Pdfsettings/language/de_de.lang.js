	var pdfconfig_arr = {
				ITEM_INDIVIDUAL_REQUIRED_QUOTES:'Zu den Angebotsangaben müssen Sie für die Anzeige von Artikeln unter dem Tab der individuellen Mwst. mindestens einen Eintrag auswählen.',
				ITEM_GROUP_REQUIRED_QUOTES:'Zu den Angebotsangaben müssen Sie für die Anzeige von Artikeln unter dem Tab der Gruppen Mwst. mindestens einen Eintrag auswählen.',
				ITEM_INDIVIDUAL_REQUIRED_PO:'Zu den Angaben unter Einkaufsbestellungen müssen Sie für die Anzeige von Artikeln unter dem Tab der individuellen Mwst. mindestens einen Eintrag auswählen.',
				ITEM_GROUP_REQUIRED_PO:'Zu den Angaben unter Einkaufsbestellungen müssen Sie für die Anzeige von Artikeln unter dem Tab der Gruppen Mwst. mindestens einen Eintrag auswählen.',
				ITEM_INDIVIDUAL_REQUIRED_SO:'Zu den Angaben unter Verkaufsbestellungen müssen Sie für die Anzeige von Artikeln unter dem Tab der individuellen Mwst. mindestens einen Eintrag auswählen.',
				ITEM_GROUP_REQUIRED_SO:'Zu den Angaben unter Verkaufsbestellungen müssen Sie für die Anzeige von Artikeln unter dem Tab der Gruppen Mwst. mindestens einen Eintrag auswählen.',
				ITEM_INDIVIDUAL_REQUIRED_INV:'Zu den Rechnungsangaben müssen Sie für die Anzeige von Artikeln unter dem Tab der individuellen Mwst. mindestens einen Eintrag auswählen.',
				ITEM_GROUP_REQUIRED_INV:'Zu den Rechnungsangaben müssen Sie für die Anzeige von Artikeln unter dem Tab der Gruppen Mwst. mindestens einen Eintrag auswählen.',
				TAB_GENERAL:'Allgemein',
				TAB_GROUP:'Gruppen Mwst.',
				TAB_INDIVIDUAL:'Individuelle Mwst.'
			};
